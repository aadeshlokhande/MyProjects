Its a multi purpose and useful library

